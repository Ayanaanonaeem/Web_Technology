var btn=document.getElementById("btn")

function hello() {
    alert("hello")
}